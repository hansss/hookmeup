
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<script type="text/javascript">var NREUMQ=NREUMQ||[];NREUMQ.push(["mark","firstbyte",new Date().getTime()]);</script>
<title>HookupHarvard</title>

	<!-- CSS styles -->
	<link href="http://www.chirpme.com/public/css/bootstrap.min.css?v1.1" rel="stylesheet">
	<link href="http://www.chirpme.com/public/css/style.css?v1.1" rel="stylesheet">

	<!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
	<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
	<style>
	#header {
	border-bottom: 1px solid #a4a4a4;
	background: #1ebaf4;
	padding: 10px 0 12px;
	
	background: -moz-linear-gradient(top, #B8300E 0%, #CA1912100%);
	background: -webkit-gradient(linear, left top, left bottom, color-stop(0%, #B8300E), color-stop(100%, #CA1912));
	background: -webkit-linear-gradient(top, #B8300E 0%, #CA1912 100%);
	background: -o-linear-gradient(top, #B8300E 0%, #CA1912100%);
	background: -ms-linear-gradient(top, #B8300E 0%, #CA1912 100%);
	background: linear-gradient(top, #B8300E 0%, #CA1912 100%);
}
	</style>
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.5/jquery.min.js"></script>
</head>
<body>
<div id="header">
	<div class="container">
		<div class="row">
			<h1 class="span6"><a href="/"><img src="img/img_logo3.png" width="108" height="34" alt="HookupHarvard" /></a></h1>

		</div>
	</div>
</div><!-- /#header -->
