<body>
<div id="fb-root"></div>
<script>
  // Additional JS functions here
  window.fbAsyncInit = function() {
    FB.init({
      appId      : '535694033108343', // App ID
      channelUrl : 'localhost/html/channel.html', // Channel File
      status     : true, // check login status
      cookie     : true, // enable cookies to allow the server to access the session
      xfbml      : true  // parse XFBML
    });

    // Additional init code here
    FB.getLoginStatus(function(response) {
     if (response.status === 'connected') {
      // connected
    } else if (response.status === 'not_authorized') {
    // not_authorized
    login();
    } 
    else {
    // not_logged_in
    login();
    }
 });
  };

  // Load the SDK Asynchronously
  (function(d){
     var js, id = 'facebook-jssdk', ref = d.getElementsByTagName('script')[0];
     if (d.getElementById(id)) {return;}
     js = d.createElement('script'); js.id = id; js.async = true;
     js.src = "//connect.facebook.net/en_US/all.js";
     ref.parentNode.insertBefore(js, ref);
   }(document));
   
   function login() {
    FB.login(function(response) {
        if (response.authResponse) {
            // connected
        } else {
            // cancelled
        }
    });
}
</script>

<style>
#content.home {
	background: #fff url('img/headerfile2.jpg') bottom center no-repeat;
	height: 450px;
	padding: 30px 0;
}
</style>
<script type="text/javascript">
	$(document).ready(function() {

		$('#header-popover-close').click(function(){
			$('#header-popover').fadeOut(60);

			return false;
		});

		$('#facebook-connect-btn').hover(
			function()
			{
				$('#button-popover').fadeIn(500);
				$('#facebook-connect-btn').fadeTo(250,0.5);
			},
			function()
			{
				$('#button-popover').fadeOut(500);
				$('#facebook-connect-btn').fadeTo(250,1);
			});

	});</script>
<div id="content" class="home">
	<div class="container">
		<h2 id="lead-title">Discover Who Likes You<br/>While Staying Anonymous </h2>
		<div class="aligncenter">
			<a id="facebook-connect-btn" style="cursor: pointer;"><strong>Anonymously Log In</strong></a>
			<div id="button-popover">
				<div class="button-popover-text" href="#">Currently not available</div>
				<div class="button-popover-text" href="#">in your area, coming soon!</div>
			</div>
		</div>

		<div class="bubble green-bubble bubble-1" style="bottom: 100px; left: 60px;">I think Hana is cute!</div>
		<div class="bubble pink-bubble bubble-2" style="bottom: 5px; left: 340px;">I totally want to hook up with Sydney!</div>
		<div class="bubble blue-bubble bubble-3" style="bottom: 42px; left: 608px;">How are you doing?</div>
		<div class="bubble yellow-bubble bubble-4" style="bottom: 140px; left: 750px;">OMG I like you too!</div>
	</div>
</div><!-- /#content en-us -->
	<div id="footer" class="container">
		<div class="row">
		<div class="span6">
			<ul id="footer-menu">
				<li><a href="/team">About</a></li>
				<li><a href="/jobs">Careers</a></li>
				<li><a href="mailto: info@chirpme.com">Feedback</a></li>
				<li><a href="/privacy">Privacy Policy</a></li>
			</ul>

			<div id="footer-copy">
				&copy; Hookup Harvard
			</div>
		</div>

		<div class="span6">
			<div id="footer-like">
<!--				<div class="fb-like" data-href="http://www.facebook.com/pages/ChirpMe/177353705667039" data-send="false" data-width="700" data-show-faces="false" style="float:left;position:absolute"></div>-->
			</div>
		</div>
	</div>
	</div><!-- /#footer -->
	<script type="text/javascript">if(!NREUMQ.f){NREUMQ.f=function(){NREUMQ.push(["load",new Date().getTime()]);var e=document.createElement("script");e.type="text/javascript";e.async=true;e.src="https://d1ros97qkrwjf5.cloudfront.net/42/eum/rum.js";document.body.appendChild(e);if(NREUMQ.a)NREUMQ.a();};NREUMQ.a=window.onload;window.onload=NREUMQ.f;};NREUMQ.push(["nrf2","beacon-2.newrelic.com","5dd578e240","411538","NlIBN0sCWUFRU01dXA8YIgBNClhcH2dcWFAOWgZMUA1TV0g=",0,2,new Date().getTime()]);</script>
</body>
</html>

