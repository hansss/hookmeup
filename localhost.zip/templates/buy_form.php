<form action="buy.php" method="post">
    <fieldset>
        <div class="control-group">
            <input name="symbol" placeholder="Symbol of Stock" type="text"/>
        </div>
        <div class="control-group">
            <input name="shares" placeholder="Shares" type="text"/>
        </div>
        <div class="control-group">
            <button type="submit" class="btn">Buy</button>
        </div>
    </fieldset>
</form>
