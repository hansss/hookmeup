<form action="passwordchange.php" method="post">
    <fieldset>
        <div class="control-group">
            <input  name="password" placeholder="Old Password" type="password"/>
        </div>
        <div class="control-group">
            <input name="newpassword" placeholder="New Password" type="password"/>
        </div>
        <div class="control-group">
            <input name="confirmation" placeholder="Confirm Password" type="password"/>
        </div>
        <div class="control-group">
            <button type="submit" class="btn">Change Password</button>
        </div>
    </fieldset>
