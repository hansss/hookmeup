<form action="quote.php" method="post">
    <fieldset>
        <div class="control-group">
            <input autofocus name="symbol" placeholder="Symbol of Stock" type="text"/>
        </div>
        <div class="control-group">
            <button type="submit" class="btn">Quote</button>
        </div>
    </fieldset>
</form>
