
<div id="middle">
            A share of <?php print($stock["name"]); 
            print(" (" . $stock["symbol"] .") ");
            print( "costs $" . number_format($stock["price"], 2));  ?>
 </div>
